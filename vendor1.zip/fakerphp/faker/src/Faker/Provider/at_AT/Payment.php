<?php

namespace Faker\Provider\at_AT;

/**
 * @deprecated at_AT is not an existing locale, use {@link \Faker\Provider\de_AT\Payment}.
 * @see \Faker\Provider\de_AT\Payment
 */
class Payment extends \Faker\Provider\de_AT\Payment
{
}
